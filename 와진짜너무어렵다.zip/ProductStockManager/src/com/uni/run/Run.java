package com.uni.run;

import com.uni.view.ProductMenu;

public class Run {

	public static void main(String[] args) {
		ProductMenu m = new ProductMenu();
        m.mainMenu();
	}

}
